let con=require('../../config/config');

exports.addComment=(req,res)=>{

    var uid=req.body.uid;
    var pid=req.body.pid;
    var tid=req.body.tid;
    var useremail=req.body.useremail;
    var msg=req.body.msg;
    console.log('req.body',req.body);
     var qry="insert into comments(uid,pid,tid,msg) values("+ uid +","+ pid +","+ tid +",'"+ msg +"') ";
    console.log(qry);
    con.query(qry,(error,result)=>{
        if(error) throw error;
        console.log('insert....');
        res.send(result);
    });
};

exports.showComment=(req,res)=>{


    var tid=req.params.tid;
    console.log('req.body',req.params);

    var qry="SELECT comments.msg,user.email from comments,user,project,task where comments.uid = user.uid and comments.pid = project.pid and comments.tid = task.tid and comments.tid = " + tid;
    console.log(qry);
    con.query(qry,(error,result)=>{
        if(error) throw error;
        console.log('fetch....');
        res.send(result);
    });
};