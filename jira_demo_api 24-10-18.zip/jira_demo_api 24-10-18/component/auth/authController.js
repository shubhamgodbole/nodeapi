let con=require('../../config/config');
let nodemailer = require('nodemailer');
const Cryptr = require('cryptr');
const cryptr = new Cryptr('myTotalySecretKey');
const encryptedString = cryptr.encrypt('fgmail');
const decryptedString = cryptr.decrypt('7b1aad0a9cdecc1867f9d14477');
// Login User
exports.login=(req,res)=>{
    console.log('encript', encryptedString);
    console.log('decript',decryptedString);
    var email=req.body.email;
    var pwd=req.body.pwd;
    console.log('req.body',req.body);

    // fetch all user
    let qry="select * from user where email='"+ email +"'";
    con.query(qry,(error,result)=>{
        if(error) {
            res.status(404).json({status:"not found",message:'invalid email or password'});
            throw error;
        }
        else {
            console.log(result);
            result.forEach((user) => {
                console.log(cryptr.decrypt(user.pwd) + '==' + pwd)
                if(user.verify === 'yes' ) {

                    if(cryptr.decrypt(user.pwd) === pwd ) {
                        res.status(200).json({status:"ok",response:result});
                    }
                    else {
                        res.status(404).json({status:"not found",message:'invalid email & password'});
                    }
                }
                else {
                    res.status(404).json({status:"not found",message:'email is not verified'});
                }
            });
        }
    });
};

// find user for forgot password
exports.forgotPassword=(req,res)=>{
    let email=req.body.email;
    let qry="select uid from user where email = '"+ email +"'" ;
    console.log(qry);
    con.query(qry,(error,result)=>{
        if(error) throw error;
        if (result) {
            nodemailer.createTestAccount((err, account) => {
                // create reusable transporter object using the default SMTP transport
                let transporter = nodemailer.createTransport({
                    host: 'smtp.gmail.com',
                    port: 587,
                    secure: false, // true for 465,587 false for other ports
                    auth: {
                        user: 'shubhamgodbole30129@gmail.com', // generated ethereal user
                        pass: 'Shubham@361993' // generated ethereal password
                    }
                });

                var mailOptions = {
                    from: 'shubhamgodbole30129@gmail.com',
                    to: email,
                    subject: 'Change Password',
                    html: '<h1>Welcome</h1><p>That was easy!</p><br><p><a href=http://localhost:4200/session/change>Click here</a></p>'
                }

                // send mail with defined transport object
                transporter.sendMail(mailOptions, (error, info) => {
                    if (error) {
                        return console.log(error);
                    }
                    console.log('Message sent: %s', info.messageId);
                });
            });
        }
        res.send(result);
    });
};

// change password
exports.changePassword=(req,res)=>{
    let uid = req.body.uid;
    let pwd = req.body.password;
    let qry="update user set pwd = '"+ cryptr.encrypt(pwd) +"' where uid = "+ uid +"" ;
    console.log(qry);
    con.query(qry,(error,result)=>{
        if(error) throw error;
        res.send(result);
    });
};