let con=require('../../config/config');
var nodemailer = require('nodemailer');
exports.addTask=(req,res)=>{

    var title=req.body.title;
    var desc=req.body.desc;
    var uid=req.body.uid;
    var pid=req.body.pid;
    var file=req.files.file;
    var fname=req.files.file.name;
    var priority=req.body.priority;


    console.log('req.body',uid);
    file.mv('../complete/src/assets/data/'+fname,(err)=>{
        if(err){
            console.log(err);
        }
        else
        {
            console.log("success");
        }
    });


    var qry="insert into task( `title`, `description`,`attechment`, `uid`, `pid`,`fname`,`priority`) values('"+ title +"','"+ desc +"','"+ file +"','"+ uid +"',"+ pid +",'"+ fname +"','"+ priority +"')";
    console.log(qry);
    con.query(qry,(error,result)=>{
        if(error) throw error;
        console.log('insert....');
        res.status(200).json({status:"ok",message:"Created New Task Sucessfuly"});
    });


    // send email to notify user
    /*uid.forEach((id) => {
        var qry1="select email from user where uid =" + id;
        console.log(qry1);
        con.query(qry1,(error,result)=>{
            if(error) throw error;
            console.log(result[0].email)
            nodemailer.createTestAccount((err, account) => {
                // create reusable transporter object using the default SMTP transport
                let transporter = nodemailer.createTransport({
                    host: 'smtp.gmail.com',
                    port: 587,
                    secure: false, // true for 465,587 false for other ports
                    auth: {
                        user: 'shubhamgodbole30129@gmail.com', // generated ethereal user
                        pass: 'Shubham@361993' // generated ethereal password
                    }
                });

                var mailOptions = {
                    from: 'shubhamgodbole30129@gmail.com',
                    to: result[0].email,
                    subject: 'New Task',
                    html: '<h1>Welcome</h1><p>That was easy!</p><br>New Task is assign to you'
                }

                // send mail with defined transport object
                transporter.sendMail(mailOptions, (error, info) => {
                    if (error) {
                        return console.log(error);
                    }
                    console.log('Message sent: %s', info.messageId);
                });
            });
        });
    });*/
};


// show all Tasks
exports.showTask=(req,res)=>{
    let qry="select * from task";
    // let qry="select * from task where uid = 2";
    con.query(qry,(error,result)=>{
        if(error) throw error;
        res.send(result);
    });
};

// Find task by id for edit
exports.findTask=(req,res)=>{
    console.log('req.body',req.params);
    let id=req.params.id;
    let qry="select * from task where tid="+id;
    console.log(qry);
    con.query(qry,(error,result)=>{
        if(error) throw error;
        res.send(result);
    });
};

// Update Task
exports.updateTask=(req,res)=>{
    let uid=req.body.uid;
    let tid=req.body.tid;
    var title=req.body.title;
    var desc=req.body.desc;
    var file=req.body.fup;
    var fname=req.body.fname;
    var priority=req.body.priority;
    console.log('req.body',req.body);
    let qry="update task set title='"+ title +"',description='"+ desc +"',uid='"+ uid +"', attechment='"+ file +"',fname ='"+ fname +"',priority = '"+ priority +"' where tid='"+ tid +"'";
    console.log(qry);

    con.query(qry,(error,result)=>{
        if(error) throw error;
        console.log('update....');
        res.status(200).json({status:"ok",message:"Task is updated Sucessfuly"});
    });

};

// find Tasks for user
exports.showTaskUser=(req,res)=>{
    console.log('req.body',req.params);
    let uid=req.params.uid;
    let pid=req.params.pid;
   // let qry="select task.tid,task.title,task.description,task.attechment,task.uid from task,user,project where user.uid ="+ uid +" and project.pid ="+ pid +"";
    let qry="select task.tid,task.title,task.description,task.attechment,task.fname,task.uid,task.priority from task where  task.pid ="+ pid +"";
    console.log(qry);
    // let qry="select * from task where uid = 2";
    con.query(qry,(error,result)=>{
        if(error) throw error;
        res.send(result);
    });
};